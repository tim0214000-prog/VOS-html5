/**
 * File: global-script.js
 * Copyright (c) 2020 Harmonic, Inc.
 * This script should included in the <head> portion of the HTML.
 * This file should be included after the harmonic-template library.
 * Revision:
 * v02 - shahril - prevent GFXPROXY http request issue by adding http header to avoid using cache
 *				 - add protection to avoid double overlapping http request
 * v03 - shahril - change reload cfg/data every 1sec 
 * v05 - shahril - Add horizontal offset for Taiwan requirement															   
 */

//------------------------------------------------------------------------------
// Global Variables
//------------------------------------------------------------------------------
let scroll = "";
let url = "";
let FetchUrl = "";
let DataFileName = ""
let ConfigData = "";
let TextData = "";
let prevConfigData = "";
let prevTextData = "";
let position = 1000;
let speed = 3;
let loopMax = 0;
let loopCount = 1;
let duration = 0;
let durationStart = 0;
let durationDelta = 0;
let prevLoopMax = 0;
let prevDuration = 0;
let txtSize = "34";
let txtTransp = "1";
let txtColor = "255,255,255";
let bckColor = "";
let Offset = "";
let FontName = "";
let CfgLoadComplete = true;

//------------------------------------------------------------------------------
// Event Handler Registration
//------------------------------------------------------------------------------
// HarmonicTemplate.LOAD_COMPLETE_EVENT : once this event has been dispatched, clients can access all registered widgets.
document.addEventListener(HarmonicTemplate.LOAD_COMPLETE_EVENT, onLoadComplete.bind(this));
// HarmonicTextScroll.TEXT_SCROLL_FINISHED : this event is dispatched when the text scroll finishes a cycle.
document.addEventListener(HarmonicTextScroll.TEXT_SCROLL_FINISHED_EVENT, onTextScrollFinished.bind(this));

//------------------------------------------------------------------------------
// Methods
//------------------------------------------------------------------------------
// HarmonicTemplate.LOAD_COMPLETE_EVENT handler.
function onLoadComplete(obj) {
	
	// Initialiiaze the Scroll
	scroll = harmonicTemplate.getWidgetByFieldNum(1);
	scroll._divScroll.style.visibility = 'hidden';
	
	// Start the periodic reload config every 1 sec
	setInterval(loadCfgFile, 1000);
}

// Loading the config.xml with HTTP GET
function loadCfgFile() {
	// If previous loadCfg still not complete or empty url abort the reload
	if ( ! CfgLoadComplete || url == "" ) {
		return;
	}
	CfgLoadComplete = false;
	
	// Check if it's running on Desktop or Platform (URL contains the ip address and the port of the websocket)
	// If running on Platform - converts the URL to uses the graphics proxy located at GFXPROXY in the Platform local web server (avoiding CORS error)
	const searchParams = new URLSearchParams(window.location.search);
	if ( searchParams.get('ip') && searchParams.get('port') ) {
		FetchUrl = window.location.origin + '/GFXPROXY/' + url.substring(url.indexOf('//') + 2);
	} else {
		FetchUrl = url;
	}
	
	// hjs.info("-----------------------");
	// hjs.info("Start loadCfg " + FetchUrl);
	
	// Define action when http response complete
	const xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (this.readyState == 4) {
			CfgLoadComplete = true;
			// hjs.info("xhr response status : " + this.status.toString());
			// hjs.info("xhr response text : " + this.responseText);
			if (this.status >= 200 && this.status < 400) {
				ConfigData = this.responseText;
				
				// hjs.info("Complete loadCfg");
				// hjs.info(ConfigData);
				
				// Parse XML ConfigData
				let parser = new DOMParser();
				let dom = parser.parseFromString(ConfigData, "application/xml");
				DataFileName = dom.getElementsByTagName("DataFile")[0].textContent;
				
				// Start loading the text data file
				loadDataFile(FetchUrl.substring(0, FetchUrl.lastIndexOf("/") + 1) + DataFileName);;
			}
		}
	};
	
	// Perform the http get the config file - set the http header to avoid using cache on GFXPROXY
	xhr.open("GET", FetchUrl);
	xhr.setRequestHeader('Cache-Control', 'no-cache, no-store, max-age=0');
	xhr.setRequestHeader('Expires', 'Thu, 1 Jan 1970 00:00:00 GMT');
	xhr.setRequestHeader('Pragma', 'no-cache');
	xhr.send();
}

// Loading the DataFile with HTTP GET
function loadDataFile(urlDataFile){
	
	// Define action when http response complete
	const xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (this.readyState == 4) {
			// hjs.info("xhr response status : " + this.status.toString());
			// hjs.info("xhr response text : " + this.responseText);
			if (this.status >= 200 && this.status < 400) {
				TextData = this.responseText;
				
				// hjs.info("Complete loadDataFile");
				// hjs.info(TextData);
				
				updateTextScroll();
			}
		}
	};
	
	// Perform the http get the data file - set the http header to avoid using cache on GFXPROXY
	xhr.open("GET", urlDataFile);
	xhr.setRequestHeader('Cache-Control', 'no-cache, no-store, max-age=0');
	xhr.setRequestHeader('Expires', 'Thu, 1 Jan 1970 00:00:00 GMT');
	xhr.setRequestHeader('Pragma', 'no-cache');
	xhr.send();
	
	// hjs.info("Start loadDataFile " + urlDataFile);
}

// This function will run once the http request for dataFile succesfully responded
function updateTextScroll(){
	
	// Check if config.xml content changed to update the crawler settings
	if ( prevConfigData != ConfigData ){
		prevConfigData = ConfigData;
		
		// Parse XML ConfigData
		let parser = new DOMParser();
		let dom = parser.parseFromString(ConfigData, "application/xml");
		position = dom.getElementsByTagName("Pos")[0].textContent;
		speed = parseInt(dom.getElementsByTagName("Speed")[0].textContent, 10);
		loopMax = parseInt(dom.getElementsByTagName("Loop")[0].textContent, 10);
		duration = parseInt(dom.getElementsByTagName("Duration")[0].textContent, 10);
		txtSize = dom.getElementsByTagName("TxtSize")[0].textContent;
		txtTransp = parseInt(dom.getElementsByTagName("TxtTransp")[0].textContent, 10) / 100;
		txtColor = dom.getElementsByTagName("TxtColor")[0].textContent;
		bckColor = dom.getElementsByTagName("BckColor")[0].textContent;
		Offset = dom.getElementsByTagName("Offset")[0].textContent;
		FontName = dom.getElementsByTagName("Font")[0].textContent;
		
		// Update the crawler speed/size/position/HorizontalOffset/FontName
		scroll.speed = speed;
		scroll.widgetObj.style.fontSize = (parseInt(txtSize,10)*0.8).toString() + "px";
		scroll.widgetObj.style.width = txtSize + "px";
		scroll.widgetObj.style.lineHeight = "120%";
		scroll.widgetObj.style.fontFamily = FontName;
		txtColor = parseInt("0x" + txtColor.substring(0,2), 16).toString() + "," + parseInt("0x" + txtColor.substring(2,4), 16).toString() + "," + parseInt("0x" + txtColor.substring(4,6), 16).toString();
		scroll.widgetObj.style.color = "rgba(" + txtColor + "," + txtTransp.toString() + ")";
		scroll.stopFieldAnimation(true);
		scroll.updateTextField(TextData,true)
		scroll.restartFieldAnimation(true);
		scroll._divScroll.style.left = position + "px";
		scroll._divScroll.style.width = txtSize + "px";
		scroll._divScroll.style.clip = "rect(" + parseInt(Offset,10).toString() + "px, " + txtSize + "px, " + (1080 - parseInt(Offset,10)).toString() + "px, 0px)";
		// Update the crawler background color if applicable
		if ( bckColor != "" ) {
			bckColor = parseInt("0x" + bckColor.substring(0,2), 16).toString() + "," + parseInt("0x" + bckColor.substring(2,4), 16).toString() + "," + parseInt("0x" + bckColor.substring(4,6), 16).toString();
			scroll._divScroll.style.backgroundColor = "rgb(" + bckColor + ")";
		} else {
			scroll._divScroll.style.backgroundColor = "";
		}
	}
	
	// Check if crawler not enabled and new data/loop/duration restart the crawler. Else wait until current crawler finished
	if ( scroll._divScroll.style.visibility == 'hidden' && (TextData != prevTextData || loopMax != prevLoopMax || duration != prevDuration) ){
		prevTextData = TextData;
		prevLoopMax = loopMax;
		prevDuration = duration;
		if (loopMax != 0){
			loopCount = 1;
		}
		if (duration != 0){
			let DateTime = new Date();
			durationStart = DateTime.getTime();
		}
		
		scroll.updateTextField(TextData,true)
		scroll.restartFieldAnimation(true);
		scroll._divScroll.style.visibility = 'visible';
		hjs.info("Crawler new start immediate : loop " + loopCount.toString() + "/" + loopMax.toString() + "  duration " + durationDelta.toString() + "/" + duration.toString());
	}
	
	// hjs.info("Complete update Crawler");
}

// HarmonicTextScroll.TEXT_SCROLL_FINISHED event handler.
function onTextScrollFinished(event) {
	// hjs.info("Complete Crawler")
	
	// Check if new settings or data to restart the loop/duration
	if (TextData != prevTextData || loopMax != prevLoopMax || duration != prevDuration){
		prevTextData = TextData;
		prevLoopMax = loopMax;
		prevDuration = duration;
		if (loopMax != 0){
			loopCount = 1;
		}
		if (duration != 0){
			let DateTime = new Date();
			durationStart = DateTime.getTime();
		}
		
		scroll.updateTextField(TextData,true)
		scroll.restartFieldAnimation(true);
		scroll._divScroll.style.visibility = 'visible';
		hjs.info("Crawler new start waited : loop " + loopCount.toString() + "/" + loopMax.toString() + "  duration " + durationDelta.toString() + "/" + duration.toString());
		
	// Else increase loopCount
	} else if (loopMax != 0 && loopCount <= loopMax){
		loopCount++;
	// Else re-calculate durationDelta
	} else if (duration != 0 && durationDelta <= duration){
		let DateTime = new Date();
		durationDelta = (DateTime.getTime() - durationStart) / 1000;
	}
		
	// Disable crawler if "text data empty or loopMax or duration reached"
	if (scroll._divScroll.style.visibility == 'visible' && ((loopMax != 0 && loopCount > loopMax) || (duration != 0 && durationDelta > duration) || (TextData == "")) ){
		// document.getElementById(ScrollWidgetNamePart).style.visibility = 'hidden';
		scroll._divScroll.style.visibility = 'hidden';
		scroll.updateTextField("",true)
		scroll.restartFieldAnimation(true);
		hjs.info("Crawler stopped : loop " + loopCount.toString() + "/" + loopMax.toString() + "  duration " + durationDelta.toString() + "/" + duration.toString());
	}
}

// updateTextField handler ie : hjstest.updateTextField(0,"http://localhost:50932/config.xml",true)
function updateTextFieldOverride(obj) {
    hjs.info("updateTextFieldOverride: " + JSON.stringify(obj));
    switch (obj.fieldNum) {
    case 0: // url
        url = obj.text;
        break;
    default:
        harmonicTemplate.updateTextField(obj);
        break;
    }
}

// Create the override object and register it with the harmonicTemplate
let override = {
    updateTextField: updateTextFieldOverride
}
harmonicTemplate.registerOverride(override);
